﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace De8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string Phai;
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=ADMIN\HUY;Initial Catalog=QLKT;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        void HienThi()
        {
            command = connection.CreateCommand();
            command.CommandText = "select *from NhanVien";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            HienThi();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            if (rdbNam.Checked)
            {
                Phai = "Nam";
            }
            else
            {
                Phai = "Nu";
            }
            command.CommandText = "insert into NhanVien values('" + txtMaNV.Text + "','" + txtTenNV.Text + "','" + dtpNgaySinh.Value.ToString("MM/dd/yyyy") + "','" + Phai + "','" + txtDiaChi.Text + "','" + txtSDT.Text+ "')";

            command.ExecuteNonQuery();
            HienThi();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            if (rdbNam.Checked)
            {
                Phai = "Nam";
            }
            else
            {
                Phai = "Nu";
            }
            command.CommandText = "update NhanVien set " + "TenNV='" + txtTenNV.Text + "',NgaySinh='" + dtpNgaySinh.Value.ToString("MM/dd/yyyy") + "',Phai='" + Phai + "',DiaChi='" + txtDiaChi.Text + "',SDT='" + txtSDT.Text + "' where MaNV='"+txtMaNV.Text+"'";

            command.ExecuteNonQuery();
            HienThi();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "delete from NhanVien where MaNV='" + txtMaNV.Text + "'";
            command.ExecuteNonQuery();
            HienThi();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            int i;
            i = dataGridView1.CurrentRow.Index;
            txtMaNV.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            txtTenNV.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            dtpNgaySinh.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            Phai=dataGridView1.Rows[i].Cells[3].Value.ToString();
            if(Phai=="Nam")
            {
                rdbNam.Checked = true;
            }
            else
            {
                rdbNu.Checked = true;
            }    
            txtDiaChi.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
            txtSDT.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
            
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            if (ckbTenNV.Checked && ckbNgaySinh.Checked)
            {
                command.CommandText = "select *from NhanVien where TenNV='" + txtTimtenNV.Text + "' and NgaySinh='" + dtpTimNgaySinh.Value.ToString("MM/dd/yyyy") + "'";

            }
            else
            {
                if (ckbTenNV.Checked)
                {
                    command.CommandText = "select *from NHanVien where TenNV='" + txtTimtenNV.Text + "'";
                }
                else
                {
                    if (ckbNgaySinh.Checked)
                    {
                        command.CommandText = "select *from NhanVien where NgaySinh='" + dtpTimNgaySinh.Value.ToString("MM/dd/yyyy") + "'";
                    }
                    else
                    {
                        command.CommandText = "select *from NhanVien ";
                    }
                }
            }
            command.ExecuteNonQuery();
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;

        }
    }
}
