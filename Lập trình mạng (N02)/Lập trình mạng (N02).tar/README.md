Cách chạy bài tư cách:
Đầu tiên mở Server bằng lệnh go run ServerTC.go (phải chỉnh thư mục làm việc về thư mục chứa SERVER)
Tiếp theo Split terminal và ở terminal thứ 2 gõ go run ClientTC.go (phải chỉnh thư mục làm việc về thư mục chứa CLIENT)
Có thể Split thêm Client để chạy thử với nhiều ClientTC.go 